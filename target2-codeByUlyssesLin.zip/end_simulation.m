function [value, isterminal, direction] = end_simulation(t,y)

% stop if the cell voltage goes below 2.5
value(1) = y(end) -2.5;
isterminal(1) = 1;
direction(1) = 0;

N = (length(y) - 1) / 3;

% stop if the theta value is bigger than 1
value(2:N+1) = y(1:N) - 1;
isterminal(2:N+1) = 1;
direction(2:N+1) = 0;

end

