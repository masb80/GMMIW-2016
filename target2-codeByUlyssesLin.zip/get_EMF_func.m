function EMF = get_EMF_func(data)

% load whole thing.
    if isempty(data)
        load('data_B.mat');
    end

    % find a full charge discharge cycle.
    j = 1;
    for i = 1:length(data)
        if data(i,2) == 3 || data(i,2) == 4 || data(i,2) == 5
            data_full_1(j,:) = data(i,:);
            j = j+1;
        end
    end

    % units right (mV to V).
    data_full_1(:,4) = data_full_1(:,4)./1000;

    first_ID = find(data_full_1(:,2) == 3);
    third_ID = find(data_full_1(:,2) == 5);

    t_discharge = data_full_1(third_ID,3)./60;
    E_discharge = data_full_1(third_ID,4);
    E_charge = flip(data_full_1(first_ID,4));

    space_to_fill = length(E_discharge)-length(E_charge);
    to_fill_E = zeros(space_to_fill,1)+E_charge(1,1);
    E_charge = [to_fill_E; E_charge];
    t_discharge = t_discharge/t_discharge(end);

    % interpolation (average)
    E_av = (E_charge(space_to_fill+1:end)+E_discharge(space_to_fill+1:end))/2;
    t_av = t_discharge(space_to_fill+1:end);

    % and add a straight line at the beginning.
    x1 = 0;
    y1 = 4.195;
    x2 = t_av(1);
    y2 = E_av(1);

    m = (y2-y1)/(x2-x1);
    x = t_discharge(1:space_to_fill);
    y = m.*(x-x1)+y1;

    E_av = [y; E_av];
    t_av = t_discharge;

    %%% spline.

    E_av_spline = spline(t_av,E_av);
    
    EMF = @(t) ppval(E_av_spline,t);
end