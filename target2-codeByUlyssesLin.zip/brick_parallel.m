function output = brick_parallel(t,y,alpha,I,R,C,N,EMF)
% N:        the number of cells, scalar
% alpha:    the proportionality constant, N*1
% I:        the current, scalar
% R:        resistance, N*1
% C:        capacitancy, N*1
% EMF:      EMF, function object taking 1 argument

output = zeros(N*3+1,1);
% 
% % e1, e2 and I can be functions of t, SOD, voltage and current
% e1 = 2;
% e2 = 2;
% I = 5;

% Writing the system of ODE
% EMFt = EMF(t); % EMF at time t
EMFt = EMF(y(1:N));
output(1:N) = alpha .* y(2*N+1:3*N); % for SOD
output(N+1:2*N) = - 1./ C .* (y(2*N+1:3*N)+y(N+1:2*N) ./ R); % for voltage
output(2*N+1:3*N) = EMFt - y(3*N+1) + y(N+1:2*N) - y(2*N+1:3*N).*R; % for current
output(3*N+1) = sum(y(2*N+1:3*N)) - I;

% 
% output(1) = a1 .* y(5);
% output(2) = a2 .* y(6);
% output(3) = -1 ./ c1 .* (y(5) + y(3) ./ r1);
% output(4) = -1 ./ c2 .* (y(6) + y(4) ./ r2);
% output(5) = e1 - e2 + y(3) - y(4) + r1 .* y(5) - r2 .* y(6);
% output(6) = y(5) + y(6) - I;
