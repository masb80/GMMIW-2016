function [t_fail,V] = simulate_fun_parallel(alpha,C,R1,capacitancy,I,tspan,EMF,N)
    
    y0 = zeros(3*N+1,1);
    y0(1:N) = 0;
    EMF0 = EMF(y0(1:N));
    y0(end) = 4.2;
    y0(2*N+1:3*N) = I .* C / sum(C);
    y0(N+1:2*N) = y0(2*N+1:3*N).*R1 + y0(end) - EMF0;
    
    t_fail = Inf;
    
    % Mass matrix
    M = diag([ones(2*N,1);zeros(N+1,1)]);
    opts = odeset('Mass',M,'Events',@end_simulation);
    
    
    %it = 1;
    %while it < 10
        %t_step = linspace(0,T_end*it,T_end*it+1);
    %    it = it + 1;
        % Solving for SOD's, voltages and currents
        [t,y,te,~] = ode23t(@(t,y) brick_parallel(t,y,alpha./C,I,R1,capacitancy,N,EMF),...
            tspan, y0, opts);
        V = y(:,end);
        % here to call DAE solver to solve the DAE system and get V as a
        % function of time t
        
        if ~isempty(te)
            t_fail = te(1);
            return;
        elseif all(V > 2.5)
            warning('time span is too narrow. try increasing the end of time.');
            t_fail = Inf;
     %       break;
        else
            t_fail = t(find(V<2.5,1));
     %       break;
        end
        % compute output power
    %end
end