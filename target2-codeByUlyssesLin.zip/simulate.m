%% simulation on a single brick where cells are parallel
clear;
alpha = 1; % the constant for d\theta/dt = (\alpha/C) t
R1C = 85; % from data fitting
R1 = 0.11; % from data fitting
nSimu = 100;

%% simulation scenario I: (Gaussian, 12*6 v.s. 6*12)
N = 12; % # cells in parallel
S = 6; % # bricks in series
T_end = 7104/3600;
distribution = 'Gaussian';
verbose = true;
randn('seed',5483986);
rand('seed',8690);
[T_min_I1,Energy_I1,Stat] = simulate_const_current(nSimu,T_end,N,S,distribution,verbose);
Stat
figure(1)
hist(T_min_I1);
figure(2)
hist(Energy_I1);

N = 6;
S = 12;
[T_min_I2,Energy_I2,Stat] = simulate_const_current(nSimu,T_end,N,S,distribution,verbose);
Stat
figure(3)
hist(T_min_I2);
figure(4)
hist(Energy_I2);

%% simulation scenario II: (Binary, 12*6 v.s. 6*12)
N = 12;
S = 6;
T_end = 7104/3600;
distribution = 'binary';
verbose = true;
randn('seed',9544);
rand('seed',2490654);
[T_min_II1,Energy_II1,Stat] = simulate_const_current(nSimu,T_end,N,S,distribution,verbose);
Stat
figure(5)
hist(T_min_II1);
figure(6)
hist(Energy_II1);

N = 6;
S = 12;
[T_min_II2,Energy_II2,Stat] = simulate_const_current(nSimu,T_end,N,S,distribution,verbose);
Stat
figure(7)
hist(T_min_II2);
figure(8)
hist(Energy_II2);

%%

%% simulation scenario II: (Binary, 12*6 v.s. 6*12)
N = 12*6;
S = 1;
T_end = 7104/3600;
distribution = 'binary';
verbose = true;
randn('seed',9544);
rand('seed',2490654);
[T_min_II1,Energy_II1,Stat] = simulate_const_current(nSimu,T_end,N,S,distribution,verbose);
Stat
figure(5)
hist(T_min_II1);
figure(6)
hist(Energy_II1);

N = 6;
S = 12;
[T_min_II2,Energy_II2,Stat] = simulate_const_current(nSimu,T_end,N,S,distribution,verbose);
Stat
figure(7)
hist(T_min_II2);
figure(8)
hist(Energy_II2);


%% something might be useful

% 
% %% simulation scenario II: capacity is normally distributed
% mu = 3.25;
% sig = mu * 0.05;
% C = randn(N,S,nSimu)*sig + mu; % randomly generated capacity of each cell of all simulation runs
% EMFfunc = get_EMF_func([]);
% T_fails = Inf(S,nSimu);
% T_min = zeros(1,nSimu);
% M = 100;
% tspan = linspace(0,T_end*1.2,M);
% V = zeros(M,S,nSimu);
% Energy = zeros(1,nSimu);
% for r = 1:nSimu
%     disp(['r=' num2str(r)]);
%     
%     for j = 1:S
%         capacity = C(:,j,r);
%         [t_fail,Vj] = simulate_fun_parallel(alpha,capacity,R1,R1C/R1,I,tspan,EMFfunc,N);
%         T_fails(j,r) = t_fail;
%         V(1:length(Vj),j,r) = Vj;
%     end
%     tmin = min(T_fails(:,r));
%     T_min(r) = tmin;
%     idx = tspan<=tmin;
%     Energy(r) = trapz(tspan(idx),sum(V(idx,:,r),2)) * I;
%     
%     disp(['the brick breaks down at t=' num2str(min(T_fails(:,r))) ' hour, E=' num2str(Energy(r))]);
%     % do statistics here
%     %[result] = simulate_fun_series(alpha,C(r,:),R1,R1C,I,EMF);
%     % do statistics here
% end
% mean(T_min)
% std(T_min)
% mean(Energy)
% std(Energy)
% % compute summary here
% 
% %% simulation scenario II: capacity is binary distributed
% p = 0.9; % for good
% q = 1-p; % for bad
% C_perfect = 3.25;
% C_defect = C_perfect / 2;
% N_perfect = round(nSimu * p * N);
% N_defect = nSimu * N  - N_perfect;
% C = randperm([C_perfect*ones(1,N_perfect),C_defect*ones(1,N_defect)]);
% C = reshape(C,nSimu,N);
% 
% for r = 1:nSimu
%     [result] = simulate_fun_parallel(alpha,C(r,:),R1,R1C,I,EMF);
%     % do statistics here
%     [result] = simulate_fun_series(alpha,C(r,:),R1,R1C,I,EMF);
%     % do statistics here
% end
% % compute summary here
% 
% %% beta distribution (if time permitted)
% t = linspace(0,1,100);
% alpha = 5;
% beta = 1;
% plot(t,betapdf(t,alpha,beta))
