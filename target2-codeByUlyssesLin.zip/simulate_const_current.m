function [T_min,Energy,Stat] = simulate_const_current(nSimu,T_end,N,S,distribution,verbose)
    

    alpha = 1; % the constant for d\theta/dt = (\alpha/C) t
    R1C = 85; % from data fitting
    R1 = 0.11; % from data fitting
    I = 1.625 * N; % the total current out of brick

    if strcmp(distribution,'Gaussian')
        mu = 3.25;
        sig = mu * 0.05;
        C = randn(N,S,nSimu)*sig + mu; % randomly generated capacity of each cell of all simulation runs
    elseif strcmp(distribution,'binary')
        p = 0.9; % for good
        %q = 1-p; % for bad
        C_perfect = 3.25;
        C_defect = C_perfect / 2;
        N_perfect = round(nSimu * p * N * S);
        N_defect = nSimu * N * S  - N_perfect;
        C = [C_perfect*ones(1,N_perfect),C_defect*ones(1,N_defect)];
        C = C(randperm(nSimu*N*S));
        C = reshape(C,N,S,nSimu);
    end
    
    EMFfunc = get_EMF_func([]);
    T_fails = Inf(S,nSimu);
    T_min = zeros(1,nSimu);
    M = 100;
    %tspan = linspace(0,T_end*1.2,M);
    V = zeros(M,S,nSimu);
    Energy = zeros(1,nSimu);
    
    for r = 1:nSimu
        tspan = [0,sort(rand(1,M-2)*T_end*1.2),T_end*1.2];
        for j = 1:S
            capacity = C(:,j,r);
            [t_fail,Vj] = simulate_fun_parallel(alpha,capacity,R1,R1C./R1,I,tspan,EMFfunc,N);
            T_fails(j,r) = t_fail;
            V(1:length(Vj),j,r) = Vj;
        end
        tmin = min(T_fails(:,r));
        T_min(r) = tmin;
        idx = tspan<=tmin;
        Energy(r) = trapz(tspan(idx),sum(V(idx,:,r),2)) * I;

        if verbose
            disp(['r=' num2str(r) ': the brick breaks down at t=' num2str(min(T_fails(:,r))) ' hour, E=' num2str(Energy(r))]);
        end
    end
    Stat.mean_Tfails = mean(T_min);
    Stat.std_Tfails = std(T_min);
    Stat.mean_Energy = mean(Energy);
    Stat.std_Energy = std(Energy);
end
